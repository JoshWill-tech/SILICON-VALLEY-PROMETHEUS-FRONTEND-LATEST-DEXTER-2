# Team video review — video review

Project: video-review-proof

## 1. Original · 00:01.250

Captured: 2026-10-15T19:35:56.930Z

Move the caption up
Keep this timing — جيد

Drawing marks: 3
Screenshot: frames/001-original-00-01.250-annotated.png

## 2. Rendered MP4 · 00:02.500
Render: review-render-proof
Captured: 2026-10-15T19:36:05.702Z

Recover this draft

Drawing marks: 0
Screenshot: frames/002-rendered-00-02.500-annotated.png
